648×648 的 png 格式，透明背景。

压缩包国内分流：[https://pan.shifeiti.com/d/123/download/A-SOUL-emoji.zip](https://pan.shifeiti.com/d/123/download/A-SOUL-emoji.zip)。

另提供了图片直链，可访问 [https://www.shifeiti.com/wiki/A-SOUL-emoji/](https://www.shifeiti.com/wiki/A-SOUL-emoji/) 查看详情。

![](https://pic.rmb.bdstatic.com/bjh/a2abf8222cee5ab06b9f94b081a0fc7f.png)